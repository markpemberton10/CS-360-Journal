package com.example.weightloss;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;

public class DashBoardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        RecyclerView recyclerView = findViewById(R.id.weightRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        ArrayList<String> sampleData = new ArrayList<>();
        sampleData.add("01/30/2026 - 180 lbs");
        sampleData.add("01/31/2026 - 179 lbs");

        recyclerView.setAdapter(new WeightAdapter(sampleData));

        FloatingActionButton fab = findViewById(R.id.addWeightButton);
        fab.setOnClickListener(v ->
                startActivity(new Intent(this, PermissionsActivity.class)));
    }
}