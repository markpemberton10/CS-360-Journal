package com.example.weightloss;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper db;
    GridView gridView;
    Button addBtn;

    private static final int SMS_PERMISSION_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);
        gridView = findViewById(R.id.gridView);
        addBtn = findViewById(R.id.addWeightButton);

        loadData();
        checkSMSPermission();
    }

    private void loadData() {
        Cursor cursor = db.getAllWeights();

        String[] from = {"date", "weight"};
        int[] to = {R.id.dateText, R.id.weightText};

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this, R.layout.grid_item, cursor, from, to, 0);

        gridView.setAdapter(adapter);
    }

    private void checkSMSPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        } else {
            sendGoalReachedSMS();
        }
    }

    private void sendGoalReachedSMS() {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage("5554", null,
                "Congratulations! You are progressing toward your goal!",
                null, null);
    }
}
